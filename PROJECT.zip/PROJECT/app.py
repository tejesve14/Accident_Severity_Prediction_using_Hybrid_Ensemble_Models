"""
Road Accident Severity Predictor — Dark Theme
==============================================
Run:
    pip install streamlit scikit-learn imbalanced-learn numpy shap matplotlib
    streamlit run app.py
Place stack_model.pkl and rf_model.pkl in the same folder.
"""

import streamlit as st
import pickle
import numpy as np
import shap
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
import warnings
warnings.filterwarnings("ignore")


# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(page_title="Accident Severity Predictor", page_icon="🚗", layout="centered")

# ── Dark theme CSS ────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); }
.main .block-container { max-width: 720px; padding-top: 2rem; padding-bottom: 3rem; }
.header-card {
    background: linear-gradient(135deg, #1e3a5f, #0f4c75);
    border-radius: 16px; padding: 1.8rem 2.2rem; margin-bottom: 2rem;
    border: 1px solid rgba(99,179,237,0.25);
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}
.header-card h2 { color: #e2f0fb; font-size: 1.65rem; font-weight: 700; margin: 0 0 0.3rem; }
.header-card p  { color: #94c4e0; margin: 0; font-size: 0.92rem; }
.sec {
    color: #63b3ed; font-size: 0.72rem; font-weight: 700;
    letter-spacing: 0.12em; text-transform: uppercase; margin: 1.6rem 0 0.5rem;
}
label, .stSelectbox label, .stSlider label {
    color: #cbd5e1 !important; font-size: 0.88rem !important; font-weight: 500 !important;
}
.stSelectbox > div > div {
    background: #1e2d3d !important; border: 1px solid #334155 !important;
    color: #e2e8f0 !important; border-radius: 8px !important;
}
.stSelectbox > div > div:hover { border-color: #63b3ed !important; }
.stSelectbox svg { fill: #63b3ed !important; }
.stSlider > div { color: #cbd5e1 !important; }
[data-baseweb="slider"] div[role="slider"] { background: #63b3ed !important; }
.cond-block {
    background: rgba(99,179,237,0.08); border-left: 3px solid #63b3ed;
    border-radius: 10px; padding: 1rem 1.2rem; margin: 0.8rem 0 0.4rem;
}
.cond-title {
    font-size: 0.75rem; font-weight: 700; color: #63b3ed;
    text-transform: uppercase; letter-spacing: 0.09em; margin-bottom: 0.6rem;
}
.stButton > button {
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: #fff; border: none; border-radius: 10px;
    font-size: 1rem; font-weight: 600; font-family: 'DM Sans', sans-serif;
    width: 100%; padding: 0.72rem 0; margin-top: 1.5rem;
    box-shadow: 0 4px 15px rgba(37,99,235,0.4); transition: all 0.2s ease;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    transform: translateY(-1px); box-shadow: 0 6px 20px rgba(37,99,235,0.5);
}
.card { border-radius: 14px; padding: 1.5rem 2rem; margin-top: 1.5rem; }
.card-green  { background: linear-gradient(135deg,#064e3b,#065f46); border: 1px solid #10b981; }
.card-yellow { background: linear-gradient(135deg,#451a03,#78350f); border: 1px solid #f59e0b; }
.card-red    { background: linear-gradient(135deg,#450a0a,#7f1d1d); border: 1px solid #ef4444; }
.card-icon  { font-size: 2rem; margin-bottom: 0.3rem; }
.card-title { font-size: 1.35rem; font-weight: 700; color: #f1f5f9; margin-bottom: 0.35rem; }
.card-desc  { font-size: 0.91rem; color: #cbd5e1; line-height: 1.55; }
.tip {
    background: #0f1f30; border-left: 3px solid #63b3ed;
    border-radius: 8px; padding: 0.85rem 1.1rem; margin-top: 1rem;
    font-size: 0.87rem; color: #94b8cc; line-height: 1.55;
}
.analysis-header {
    background: linear-gradient(135deg, #1a1f35, #0f172a);
    border-radius: 14px; padding: 1.2rem 1.8rem; margin: 2rem 0 1rem;
    border: 1px solid rgba(99,179,237,0.2);
}
.analysis-header h3 { color: #63b3ed; font-size: 1.1rem; font-weight: 700; margin: 0 0 0.2rem; }
.analysis-header p  { color: #64748b; font-size: 0.82rem; margin: 0; }
hr { border-color: #1e3a5f !important; margin: 1.8rem 0 !important; }
#MainMenu, footer, header { visibility: hidden; }
</style>
""", unsafe_allow_html=True)

# ── Load models ───────────────────────────────────────────────────────────────
stack_model = pickle.load(open("stack_model.pkl", "rb"))
rf_model    = pickle.load(open("rf_model.pkl", "rb"))
model       = stack_model

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="header-card">
  <h2>🚗 Road Accident Severity Predictor</h2>
  <p>Enter the accident details below to predict whether the outcome is Slight, Serious, or Fatal.</p>
</div>
""", unsafe_allow_html=True)

# ── Encoding tables ───────────────────────────────────────────────────────────
FEATURE_NAMES = [
    "Age of Driver", "Driving Experience", "Vehicle Type", "Area Type",
    "Lane / Road Type", "Road Alignment", "Junction Type", "Road Surface",
    "Light Condition", "Weather", "Collision Type", "No. of Vehicles",
    "No. of Casualties", "Vehicle Movement", "Casualty Class",
    "Age of Casualty", "Pedestrian Movement", "Cause of Accident", "Time of Day",
]

ENC_TIME         = {"Morning   (6 AM – 12 PM)": 2, "Afternoon (12 PM – 6 PM)": 0,
                    "Evening   (6 PM – 12 AM)": 1, "Night     (12 AM – 6 AM)": 3}
ENC_AGE_DRIVER   = {"18 – 30": 0, "31 – 50": 1, "Over 51": 2}
ENC_VEHICLE      = {"Automobile": 0, "Motorcycle": 6, "Lorry": 3}
ENC_AREA         = {"Urban": 9, "Rural": 10}
ENC_LANE         = {"One way": 1, "Two way": 4}
ENC_ALIGN        = {"Straight road": 5, "Curved road": 1}
ENC_JUNCTION     = {"No junction": 1, "T-Junction": 4, "Crossroads (X)": 6}
ENC_SURFACE      = {"Dry": 0, "Wet": 3}
ENC_LIGHT        = {"Daylight": 3, "Night / Dark": 2}
ENC_WEATHER      = {"Normal": 2, "Rainy": 4, "Foggy": 1}
ENC_COLLISION    = {"Vehicle vs Vehicle": 8, "Vehicle vs Object / Roadside": 2}
ENC_CAUSE        = {"Overspeed": 15, "Overtaking": 16, "Careless driving": 3}
ENC_PEDESTRIAN   = {"Crossing the road": 0, "Walking along the road": 7}
ENC_AGE_CASUALTY = {"18 – 30": 0, "31 – 50": 1, "Over 51": 3}

# ── Form ──────────────────────────────────────────────────────────────────────
st.markdown('<p class="sec">🕐 Time & Driver</p>', unsafe_allow_html=True)
c1, c2 = st.columns(2)
with c1:
    time_band  = st.selectbox("Time of Day", list(ENC_TIME.keys()))
    age_driver = st.selectbox("Driver's Age", list(ENC_AGE_DRIVER.keys()))
with c2:
    vehicle = st.selectbox("Vehicle Type", list(ENC_VEHICLE.keys()))
    cause   = st.selectbox("Cause of Accident", list(ENC_CAUSE.keys()))

st.markdown('<p class="sec">📍 Road & Environment</p>', unsafe_allow_html=True)
c3, c4 = st.columns(2)
with c3:
    area      = st.selectbox("Area Type", list(ENC_AREA.keys()))
    lane      = st.selectbox("Lane / Road Type", list(ENC_LANE.keys()))
    alignment = st.selectbox("Road Alignment", list(ENC_ALIGN.keys()))
with c4:
    junction = st.selectbox("Junction Type", list(ENC_JUNCTION.keys()))
    surface  = st.selectbox("Road Surface", list(ENC_SURFACE.keys()))
    light    = st.selectbox("Light Condition", list(ENC_LIGHT.keys()))
    weather  = st.selectbox("Weather", list(ENC_WEATHER.keys()))

st.markdown('<p class="sec">💥 Collision</p>', unsafe_allow_html=True)
collision = st.selectbox("Type of Collision", list(ENC_COLLISION.keys()))

if collision == "Vehicle vs Vehicle":
    st.markdown('<div class="cond-block"><div class="cond-title">🚗 Vehicle vs Vehicle — extra detail</div>', unsafe_allow_html=True)
    num_vehicles = st.slider("Number of Vehicles Involved", 1, 10, 2)
    st.markdown('</div>', unsafe_allow_html=True)
    num_casualties     = 1
    age_casualty_key   = "18 – 30"
    casualty_class_enc = 0
    pedestrian_enc     = 5
else:
    st.markdown('<div class="cond-block"><div class="cond-title">🚧 Vehicle vs Object — extra details</div>', unsafe_allow_html=True)
    num_casualties   = st.slider("Number of Casualties", 1, 10, 1)
    age_casualty_key = st.selectbox("Age of Casualty", list(ENC_AGE_CASUALTY.keys()))
    pedestrian_key   = st.selectbox("Pedestrian Movement", list(ENC_PEDESTRIAN.keys()))
    st.markdown('</div>', unsafe_allow_html=True)
    num_vehicles       = 1
    casualty_class_enc = 2
    pedestrian_enc     = ENC_PEDESTRIAN[pedestrian_key]

# ── Severity map ──────────────────────────────────────────────────────────────
SEVERITY = {
    0: ("Fatal Injury",   "card-red",    "🔴",
        "The accident is predicted to result in one or more fatalities.",
        "💡 Fatal crashes are most often caused by drunk driving, extreme speed, and unsafe overtaking. Strict speed enforcement and zero alcohol tolerance save lives."),
    1: ("Serious Injury", "card-yellow", "🟡",
        "The accident likely caused significant injuries requiring hospitalisation.",
        "💡 Serious injuries are linked to poor lighting, dangerous junctions, and high speed. Always use seatbelts and slow down at intersections."),
    2: ("Slight Injury",  "card-green",  "🟢",
        "The accident likely resulted in minor injuries with no lasting harm.",
        "💡 Most slight-injury accidents involve inattention and tailgating. Staying alert and keeping a safe following distance reduces risk significantly."),
}

# ── Dark figure helper ────────────────────────────────────────────────────────
def dark_fig(w=8, h=5):
    fig, ax = plt.subplots(figsize=(w, h))
    fig.patch.set_facecolor("#0f172a")
    ax.set_facecolor("#1e2d3d")
    for spine in ax.spines.values():
        spine.set_edgecolor("#334155")
    ax.tick_params(colors="#94a3b8", labelsize=8.5)
    ax.xaxis.label.set_color("#cbd5e1")
    ax.yaxis.label.set_color("#cbd5e1")
    ax.title.set_color("#e2f0fb")
    return fig, ax


# ── Normalise SHAP output into a clean list of 3 arrays (1, n_features) ──────
def normalise_shap(raw, n_features, n_classes=3):
    if isinstance(raw, list):
        if len(raw) == n_classes:
            out = []
            for arr in raw:
                arr = np.array(arr)
                if arr.ndim == 1:
                    arr = arr.reshape(1, -1)
                out.append(arr)
            return out
        elif len(raw) == 1:
            arr = np.array(raw[0])
            if arr.ndim == 1:
                arr = arr.reshape(1, -1)
            return [arr] * n_classes

    raw = np.array(raw)

    if raw.ndim == 3 and raw.shape[2] == n_classes:
        return [raw[:, :, c] for c in range(n_classes)]

    if raw.ndim == 2 and raw.shape[0] == n_classes:
        return [raw[c:c+1, :] for c in range(n_classes)]

    if raw.ndim <= 2:
        flat = raw.reshape(1, -1)
        return [flat] * n_classes

    flat = raw.reshape(1, -1)[:, :n_features]
    return [flat] * n_classes


# ── SHAP Waterfall ────────────────────────────────────────────────────────────
def plot_shap_waterfall(shap_list, feature_names, pred_class):
    vals  = shap_list[pred_class][0]
    pairs = sorted(zip(vals, feature_names), key=lambda x: abs(x[0]), reverse=True)[:10]
    vals_s  = np.array([p[0] for p in pairs])
    names_s = [p[1] for p in pairs]
    colors  = ["#f87171" if v > 0 else "#34d399" for v in vals_s]

    fig, ax = dark_fig(8, 5)
    bars = ax.barh(range(len(vals_s)), vals_s, color=colors, edgecolor="none", height=0.62)

    for bar, val in zip(bars, vals_s):
        offset = 0.001 if val >= 0 else -0.001
        ha     = "left" if val >= 0 else "right"
        ax.text(bar.get_width() + offset, bar.get_y() + bar.get_height() / 2,
                f"{val:+.3f}", va="center", ha=ha, color="#f1f5f9", fontsize=8, fontweight="600")

    ax.set_yticks(range(len(names_s)))
    ax.set_yticklabels(names_s, fontsize=9, color="#cbd5e1")
    ax.axvline(0, color="#475569", linewidth=1.2, linestyle="--")
    ax.set_xlabel("SHAP Value  (impact on model output)", fontsize=9, color="#94a3b8")
    class_map = {0: "Fatal", 1: "Serious", 2: "Slight"}
    ax.set_title(f"🔍 Top-10 Feature Contributions  →  Predicted: {class_map.get(pred_class, '')}",
                 fontsize=11, fontweight="700", color="#e2f0fb", pad=12)
    ax.legend(handles=[mpatches.Patch(color="#f87171", label="Increases severity risk"),
                        mpatches.Patch(color="#34d399", label="Decreases severity risk")],
              loc="lower right", framealpha=0.15, edgecolor="#334155", labelcolor="#cbd5e1", fontsize=8)
    ax.invert_yaxis()
    fig.tight_layout(pad=1.6)
    return fig


# ── Feature Importance ────────────────────────────────────────────────────────
def plot_feature_importance(rf, feature_names, top_n=12):
    estimator = rf
    if hasattr(rf, "named_steps"):
        last_step = list(rf.named_steps.values())[-1]
        estimator = last_step
    if not hasattr(estimator, "feature_importances_"):
        return None

    importances = estimator.feature_importances_
    idx       = np.argsort(importances)[::-1][:top_n]
    top_imp   = importances[idx]
    top_names = [feature_names[i] for i in idx]
    norm      = (top_imp - top_imp.min()) / (top_imp.max() - top_imp.min() + 1e-9)
    palette   = [plt.cm.plasma(0.15 + 0.7 * n) for n in norm]

    fig, ax = dark_fig(8, 5.2)
    bars = ax.barh(range(top_n), top_imp[::-1], color=list(reversed(palette)),
                   edgecolor="none", height=0.65)
    for bar, val in zip(bars, top_imp[::-1]):
        ax.text(bar.get_width() + 0.001, bar.get_y() + bar.get_height() / 2,
                f"{val*100:.1f}%", va="center", fontsize=8, color="#f1f5f9", fontweight="600")

    ax.set_yticks(range(top_n))
    ax.set_yticklabels(list(reversed(top_names)), fontsize=9, color="#cbd5e1")
    ax.set_xlabel("Importance Score", fontsize=9, color="#94a3b8")
    ax.set_title(f"📊 Top-{top_n} Feature Importances",
                 fontsize=11, fontweight="700", color="#e2f0fb", pad=12)

    sm = plt.cm.ScalarMappable(cmap="plasma",
                               norm=plt.Normalize(vmin=top_imp.min(), vmax=top_imp.max()))
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, orientation="vertical", fraction=0.025, pad=0.02)
    cbar.ax.yaxis.set_tick_params(color="#94a3b8", labelsize=7)
    cbar.set_label("Importance", color="#94a3b8", fontsize=8)
    plt.setp(cbar.ax.yaxis.get_ticklabels(), color="#94a3b8")
    cbar.outline.set_edgecolor("#334155")
    fig.tight_layout(pad=1.6)
    return fig


# ── SHAP Dot Plot ─────────────────────────────────────────────────────────────
def plot_shap_dot(shap_list, feature_names):
    sv = np.stack([s[0] for s in shap_list], axis=-1)  # (n_features, 3)
    mean_abs = np.mean(np.abs(sv), axis=1)              # (n_features,)
    idx = np.argsort(mean_abs)[::-1][:10]

    cls_colors = ["#f87171", "#f59e0b", "#34d399"]
    cls_labels = ["Fatal", "Serious", "Slight"]

    fig, ax = dark_fig(8, 5)
    for rank, feat_i in enumerate(reversed(idx)):
        for cls in range(3):
            val = sv[feat_i, cls]
            ax.scatter(val, rank, color=cls_colors[cls], s=95, alpha=0.85,
                       edgecolors="none", zorder=3)

    ax.set_yticks(range(len(idx)))
    ax.set_yticklabels([feature_names[i] for i in reversed(idx)], fontsize=9, color="#cbd5e1")
    ax.axvline(0, color="#475569", linewidth=1.2, linestyle="--")
    ax.set_xlabel("SHAP Value", fontsize=9, color="#94a3b8")
    ax.set_title("🌐 SHAP Dot Plot  —  Per-Class Feature Impact",
                 fontsize=11, fontweight="700", color="#e2f0fb", pad=12)
    for lbl, col in zip(cls_labels, cls_colors):
        ax.scatter([], [], color=col, s=60, label=lbl, alpha=0.9)
    ax.legend(loc="lower right", framealpha=0.15, edgecolor="#334155",
              labelcolor="#cbd5e1", fontsize=8)
    fig.tight_layout(pad=1.6)
    return fig


# ── Rule-based prediction helper (threshold-calibrated for balanced output) ───
# The stacking model is trained on imbalanced data so it over-predicts "Slight"
# (class 2). We lower the decision thresholds for Fatal (class 0) and Serious
# (class 1) so they can win when there is meaningful evidence for them.
#
#   Fatal   fires if  P(Fatal)   >= 0.20   (was effectively ~0.40+ with argmax)
#   Serious fires if  P(Serious) >= 0.25
#   Slight  is the fallback when neither above threshold is met
#
# Hard safety rules (high vehicle/casualty counts) still override everything.
THRESH_FATAL   = 0.20
THRESH_SERIOUS = 0.25

def model_with_rules(X):
    probs     = model.predict_proba(X)   # shape (n, 3): [P(Fatal), P(Serious), P(Slight)]
    p_fatal   = probs[:, 0]
    p_serious = probs[:, 1]
    preds     = np.full(len(X), 2, dtype=int)   # default → Slight

    for i in range(len(X)):
        num_veh  = X[i][11]
        casualty = X[i][12]

        # Hard safety override (counts-based)
        if casualty >= 8 or num_veh >= 7:
            preds[i] = 0   # Fatal
            continue
        if casualty >= 5 or num_veh >= 4:
            preds[i] = 1   # Serious
            continue

        # Threshold-calibrated soft prediction
        if p_fatal[i] >= THRESH_FATAL:
            preds[i] = 0   # Fatal
        elif p_serious[i] >= THRESH_SERIOUS:
            preds[i] = 1   # Serious
        else:
            preds[i] = 2   # Slight

    return preds


# ─────────────────────────────────────────────────────────────────────────────
if st.button("🔍  Predict Severity"):

    features = np.array([[
        ENC_AGE_DRIVER[age_driver],
        2,
        ENC_VEHICLE[vehicle],
        ENC_AREA[area],
        ENC_LANE[lane],
        ENC_ALIGN[alignment],
        ENC_JUNCTION[junction],
        ENC_SURFACE[surface],
        ENC_LIGHT[light],
        ENC_WEATHER[weather],
        ENC_COLLISION[collision],
        num_vehicles - 1,
        num_casualties - 1,
        2,
        casualty_class_enc,
        ENC_AGE_CASUALTY[age_casualty_key] if collision != "Vehicle vs Vehicle" else 0,
        pedestrian_enc,
        ENC_CAUSE[cause],
        ENC_TIME[time_band],
    ]])

    pred = int(model_with_rules(features)[0])
    label, card_css, icon, desc, tip = SEVERITY.get(pred, SEVERITY[2])

    # ── Prediction card (no confidence bars) ─────────────────────────────────
    st.markdown(f"""
    <div class="card {card_css}">
      <div class="card-icon">{icon}</div>
      <div class="card-title">Predicted: {label}</div>
      <div class="card-desc">{desc}</div>
    </div>
    <div class="tip">{tip}</div>
    """, unsafe_allow_html=True)

    # ── ① SHAP Waterfall ──────────────────────────────────────────────────────
    st.markdown("""
    <div class="analysis-header">
      <h3>🔬 SHAP Explanation  —  This Prediction</h3>
      <p>How each feature pushed the model toward or away from the predicted severity class.</p>
    </div>
    """, unsafe_allow_html=True)

    shap_list = None

    try:
        # SHAP uses raw model probabilities — smooth, feature-driven signal
        # NOT the rule-based wrapper, so count-based overrides don't dominate
        # the explanation and all features contribute meaningfully.
        def shap_predict(X):
            return model.predict_proba(X)   # raw probs: shape (n, 3)

        # Diverse background: vary every feature slightly around the current
        # input so SHAP sees a real distribution, not a single-point baseline.
        rng_bg = np.random.default_rng(42)
        bg = np.tile(features[0], (30, 1)).astype(float)
        # Perturb each feature by ±1–2 encoded units to cover the input space
        bg += rng_bg.uniform(-2, 2, bg.shape)
        bg  = np.clip(np.round(bg), 0, 20)

        explainer = shap.KernelExplainer(shap_predict, bg)
        raw_shap  = explainer.shap_values(features, nsamples=200)
        shap_list = normalise_shap(raw_shap, len(FEATURE_NAMES), n_classes=3)

    except Exception as e:
        st.warning(f"SHAP could not be computed: {e}")

    if shap_list is not None:
        try:
            fig_w = plot_shap_waterfall(shap_list, FEATURE_NAMES, pred)
            st.pyplot(fig_w, use_container_width=True)
            plt.close(fig_w)
        except Exception as e:
            st.warning(f"Waterfall plot error: {e}")

    # ── ② Feature Importance ─────────────────────────────────────────────────
    st.markdown("""
    <div class="analysis-header">
      <h3>📊 Global Feature Importance </h3>
      <p>Overall contribution of each feature across all training predictions.</p>
    </div>
    """, unsafe_allow_html=True)

    try:
        fig_fi = plot_feature_importance(rf_model, FEATURE_NAMES, top_n=12)
        if fig_fi:
            st.pyplot(fig_fi, use_container_width=True)
            plt.close(fig_fi)
        else:
            st.warning("Feature importances not available on this model object.")
    except Exception as e:
        st.warning(f"Feature importance error: {e}")



# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("<hr>", unsafe_allow_html=True)
st.markdown(
    "<p style='text-align:center;color:#334155;font-size:0.78rem;'>"
    "Powered by a Stacking Ensemble Model · For educational & research use only</p>",
    unsafe_allow_html=True,
)